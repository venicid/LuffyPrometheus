# 使用

## 修改yml文件
```yaml

# consul api 地址
host: 192.168.116.130
port:  8500
  
# pushgateway 信息
pushgateway:
  # 端口号
  port: 9091
  # pushgateway ip列表
  servers:
    - 192.168.116.130
    - 192.168.116.131

```

## 运行
```yaml
python3 flask_dynamic-sharding.py
```